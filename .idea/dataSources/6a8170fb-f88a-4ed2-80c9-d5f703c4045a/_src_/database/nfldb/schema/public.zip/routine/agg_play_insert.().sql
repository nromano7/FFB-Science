create function agg_play_insert() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
                INSERT INTO
                    agg_play (gsis_id, drive_id, play_id)
                    VALUES   (NEW.gsis_id, NEW.drive_id, NEW.play_id);
                RETURN NULL;
            END;

$$;
